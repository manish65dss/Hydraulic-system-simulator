import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ComponentData, Connection } from '@/types/component';

interface ComponentContextType {
  components: ComponentData[];
  connections: Connection[];
  addComponent: (component: ComponentData) => void;
  removeComponent: (id: string) => void;
  updateComponent: (id: string, updates: Partial<ComponentData>) => void;
  addConnection: (connection: Connection) => void;
  removeConnection: (id: string) => void;
}

const ComponentContext = createContext<ComponentContextType | undefined>(undefined);

export function ComponentProvider({ children }: { children: ReactNode }) {
  const [components, setComponents] = useState<ComponentData[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);

  const addComponent = (component: ComponentData) => {
    setComponents(prev => [...prev, component]);
  };

  const removeComponent = (id: string) => {
    setComponents(prev => prev.filter(c => c.id !== id));
    setConnections(prev => prev.filter(c => c.fromId !== id && c.toId !== id));
  };

  const updateComponent = (id: string, updates: Partial<ComponentData>) => {
    setComponents(prev =>
      prev.map(c => c.id === id ? { ...c, ...updates } : c)
    );
  };

  const addConnection = (connection: Connection) => {
    setConnections(prev => [...prev, connection]);
  };

  const removeConnection = (id: string) => {
    setConnections(prev => prev.filter(c => c.id !== id));
  };

  return (
    <ComponentContext.Provider
      value={{
        components,
        connections,
        addComponent,
        removeComponent,
        updateComponent,
        addConnection,
        removeConnection,
      }}
    >
      {children}
    </ComponentContext.Provider>
  );
}

export function useComponentContext() {
  const context = useContext(ComponentContext);
  if (context === undefined) {
    throw new Error('useComponentContext must be used within a ComponentProvider');
  }
  return context;
}