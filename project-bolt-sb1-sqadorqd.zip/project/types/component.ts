export interface ComponentData {
  id: string;
  type: string;
  x: number;
  y: number;
  rotation: number;
  properties: Record<string, any>;
}

export interface Connection {
  id: string;
  fromId: string;
  toId: string;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  type: 'main' | 'pilot';
}

export interface ComponentType {
  name: string;
  description: string;
  category: string;
  renderIcon: () => JSX.Element;
  renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => JSX.Element;
  connectionPoints: Array<{
    id: string;
    x: number;
    y: number;
    type: 'inlet' | 'outlet' | 'pilot';
  }>;
}