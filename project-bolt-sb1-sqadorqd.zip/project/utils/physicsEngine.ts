interface FluidNode {
  id: string;
  pressure: number;
  flowRate: number;
  temperature: number;
  viscosity: number;
}

interface FluidConnection {
  from: string;
  to: string;
  resistance: number;
  diameter: number;
  length: number;
}

export class PhysicsEngine {
  private nodes: Map<string, FluidNode> = new Map();
  private connections: FluidConnection[] = [];
  private timeStep: number = 0.016; // 60 FPS

  addNode(id: string, initialPressure: number = 0): void {
    this.nodes.set(id, {
      id,
      pressure: initialPressure,
      flowRate: 0,
      temperature: 20, // Celsius
      viscosity: 0.032, // Hydraulic oil viscosity (Pa·s)
    });
  }

  addConnection(from: string, to: string, diameter: number, length: number): void {
    // Calculate resistance based on pipe diameter and length
    const resistance = this.calculatePipeResistance(diameter, length);
    
    this.connections.push({
      from,
      to,
      resistance,
      diameter,
      length,
    });
  }

  private calculatePipeResistance(diameter: number, length: number): number {
    // Simplified pipe resistance calculation
    // R = (128 * μ * L) / (π * d^4)
    const viscosity = 0.032; // Hydraulic oil viscosity
    return (128 * viscosity * length) / (Math.PI * Math.pow(diameter, 4));
  }

  calculateFlowRate(pressureDiff: number, resistance: number): number {
    // Flow rate based on pressure difference and resistance
    // Q = ΔP / R
    return pressureDiff / resistance;
  }

  simulate(pumps: Array<{ id: string; flowRate: number; pressure: number }>): void {
    // Reset flow rates
    this.nodes.forEach(node => {
      node.flowRate = 0;
    });

    // Apply pump pressures
    pumps.forEach(pump => {
      const node = this.nodes.get(pump.id);
      if (node) {
        node.pressure = pump.pressure;
        node.flowRate = pump.flowRate;
      }
    });

    // Calculate flow through connections
    this.connections.forEach(connection => {
      const fromNode = this.nodes.get(connection.from);
      const toNode = this.nodes.get(connection.to);
      
      if (fromNode && toNode) {
        const pressureDiff = fromNode.pressure - toNode.pressure;
        const flowRate = this.calculateFlowRate(pressureDiff, connection.resistance);
        
        // Update flow rates
        fromNode.flowRate -= flowRate;
        toNode.flowRate += flowRate;
        
        // Update pressures based on continuity equation
        const pressureChange = flowRate * connection.resistance * this.timeStep;
        fromNode.pressure -= pressureChange * 0.5;
        toNode.pressure += pressureChange * 0.5;
      }
    });

    // Apply pressure constraints (minimum pressure = 0)
    this.nodes.forEach(node => {
      node.pressure = Math.max(0, node.pressure);
    });
  }

  getNode(id: string): FluidNode | undefined {
    return this.nodes.get(id);
  }

  getFlowRate(from: string, to: string): number {
    const connection = this.connections.find(c => c.from === from && c.to === to);
    if (!connection) return 0;

    const fromNode = this.nodes.get(from);
    const toNode = this.nodes.get(to);
    
    if (fromNode && toNode) {
      const pressureDiff = fromNode.pressure - toNode.pressure;
      return this.calculateFlowRate(pressureDiff, connection.resistance);
    }
    
    return 0;
  }

  clear(): void {
    this.nodes.clear();
    this.connections = [];
  }
}

export const physicsEngine = new PhysicsEngine();