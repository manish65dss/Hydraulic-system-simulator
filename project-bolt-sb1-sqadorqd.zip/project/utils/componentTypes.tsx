import React from 'react';
import { View } from 'react-native';
import Svg, { 
  Rect, 
  Circle, 
  Line, 
  Polygon, 
  Path,
  G,
  Ellipse,
  Text as SvgText 
} from 'react-native-svg';
import { ComponentType, ComponentData } from '@/types/component';

const createIcon = (children: React.ReactNode) => (
  <Svg width={32} height={32} viewBox="0 0 32 32">
    {children}
  </Svg>
);

const createSymbol = (children: React.ReactNode) => (
  <G>
    {children}
  </G>
);

export const componentTypes: Record<string, ComponentType> = {
  pump: {
    name: 'Hydraulic Pump',
    description: 'Fixed displacement pump',
    category: 'pumps',
    renderIcon: () => createIcon(
      <>
        <Circle cx={16} cy={16} r={12} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Polygon points="12,16 20,12 20,20" fill="#2563eb" />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Circle cx={0} cy={0} r={25} fill="none" stroke="#1e40af" strokeWidth={2} />
        <Polygon points="-8,0 8,-8 8,8" fill={isSimulationRunning ? "#3b82f6" : "#64748b"} />
        <SvgText x={-4} y={35} fontSize={10} fill="#374151" textAnchor="middle">P</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'outlet', x: 25, y: 0, type: 'outlet' },
      { id: 'inlet', x: -25, y: 0, type: 'inlet' },
    ],
  },

  'variable-pump': {
    name: 'Variable Pump',
    description: 'Variable displacement pump',
    category: 'pumps',
    renderIcon: () => createIcon(
      <>
        <Circle cx={16} cy={16} r={12} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Polygon points="12,16 20,12 20,20" fill="#2563eb" />
        <Line x1={8} y1={8} x2={24} y2={24} stroke="#2563eb" strokeWidth={2} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Circle cx={0} cy={0} r={25} fill="none" stroke="#1e40af" strokeWidth={2} />
        <Polygon points="-8,0 8,-8 8,8" fill={isSimulationRunning ? "#3b82f6" : "#64748b"} />
        <Line x1={-18} y1={-18} x2={18} y2={18} stroke="#1e40af" strokeWidth={2} />
        <SvgText x={-4} y={35} fontSize={10} fill="#374151" textAnchor="middle">VP</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'outlet', x: 25, y: 0, type: 'outlet' },
      { id: 'inlet', x: -25, y: 0, type: 'inlet' },
      { id: 'control', x: 0, y: -25, type: 'pilot' },
    ],
  },

  'directional-valve': {
    name: '4/3 Directional Valve',
    description: '4-port, 3-position directional control valve',
    category: 'valves',
    renderIcon: () => createIcon(
      <>
        <Rect x={8} y={12} width={16} height={8} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Line x1={12} y1={16} x2={20} y2={16} stroke="#2563eb" strokeWidth={2} />
        <Polygon points="18,14 22,16 18,18" fill="#2563eb" />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Rect x={-30} y={-15} width={60} height={30} fill="none" stroke="#1e40af" strokeWidth={2} />
        <Line x1={-20} y1={0} x2={20} y2={0} stroke="#1e40af" strokeWidth={2} />
        <Polygon points="15,-3 25,0 15,3" fill={isSimulationRunning ? "#3b82f6" : "#64748b"} />
        <SvgText x={0} y={25} fontSize={10} fill="#374151" textAnchor="middle">4/3 DCV</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'P', x: 0, y: -15, type: 'inlet' },
      { id: 'T', x: 0, y: 15, type: 'outlet' },
      { id: 'A', x: -30, y: 0, type: 'outlet' },
      { id: 'B', x: 30, y: 0, type: 'outlet' },
    ],
  },

  'relief-valve': {
    name: 'Relief Valve',
    description: 'Pressure relief valve',
    category: 'valves',
    renderIcon: () => createIcon(
      <>
        <Line x1={16} y1={8} x2={16} y2={24} stroke="#2563eb" strokeWidth={2} />
        <Polygon points="12,12 20,12 16,20" fill="none" stroke="#2563eb" strokeWidth={2} />
        <Line x1={12} y1={8} x2={20} y2={8} stroke="#2563eb" strokeWidth={2} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Line x1={0} y1={-20} x2={0} y2={20} stroke="#1e40af" strokeWidth={2} />
        <Polygon points="-10,-10 10,-10 0,10" fill="none" stroke="#1e40af" strokeWidth={2} />
        <Line x1={-15} y1={-20} x2={15} y2={-20} stroke="#1e40af" strokeWidth={2} />
        <Line x1={-8} y1={-25} x2={8} y2={-25} stroke="#1e40af" strokeWidth={1} />
        <SvgText x={15} y={5} fontSize={10} fill="#374151">RV</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'inlet', x: 0, y: -20, type: 'inlet' },
      { id: 'outlet', x: 0, y: 20, type: 'outlet' },
    ],
  },

  'check-valve': {
    name: 'Check Valve',
    description: 'One-way flow control valve',
    category: 'valves',
    renderIcon: () => createIcon(
      <>
        <Line x1={8} y1={16} x2={24} y2={16} stroke="#2563eb" strokeWidth={2} />
        <Polygon points="14,12 18,16 14,20" fill="#2563eb" />
        <Line x1={20} y1={12} x2={20} y2={20} stroke="#2563eb" strokeWidth={2} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Line x1={-25} y1={0} x2={25} y2={0} stroke="#1e40af" strokeWidth={2} />
        <Polygon points="-5,-8 5,0 -5,8" fill={isSimulationRunning ? "#3b82f6" : "#64748b"} />
        <Line x1={10} y1={-10} x2={10} y2={10} stroke="#1e40af" strokeWidth={2} />
        <SvgText x={0} y={20} fontSize={10} fill="#374151" textAnchor="middle">CV</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'inlet', x: -25, y: 0, type: 'inlet' },
      { id: 'outlet', x: 25, y: 0, type: 'outlet' },
    ],
  },

  'flow-control-valve': {
    name: 'Flow Control Valve',
    description: 'Variable flow control valve',
    category: 'valves',
    renderIcon: () => createIcon(
      <>
        <Line x1={8} y1={16} x2={24} y2={16} stroke="#2563eb" strokeWidth={2} />
        <Rect x={14} y={12} width={4} height={8} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Line x1={10} y1={10} x2={22} y2={22} stroke="#2563eb" strokeWidth={2} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Line x1={-25} y1={0} x2={25} y2={0} stroke="#1e40af" strokeWidth={2} />
        <Rect x={-5} y={-8} width={10} height={16} fill="none" stroke="#1e40af" strokeWidth={2} />
        <Line x1={-15} y1={-15} x2={15} y2={15} stroke="#1e40af" strokeWidth={2} />
        <SvgText x={0} y={25} fontSize={10} fill="#374151" textAnchor="middle">FCV</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'inlet', x: -25, y: 0, type: 'inlet' },
      { id: 'outlet', x: 25, y: 0, type: 'outlet' },
    ],
  },

  cylinder: {
    name: 'Hydraulic Cylinder',
    description: 'Double acting hydraulic cylinder',
    category: 'actuators',
    renderIcon: () => createIcon(
      <>
        <Rect x={8} y={12} width={16} height={8} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Line x1={16} y1={12} x2={16} y2={8} stroke="#2563eb" strokeWidth={2} />
        <Line x1={14} y1={8} x2={18} y2={8} stroke="#2563eb" strokeWidth={2} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Rect x={-25} y={-10} width={50} height={20} fill="none" stroke="#1e40af" strokeWidth={2} />
        <Line x1={0} y1={-10} x2={0} y2={-25} stroke="#1e40af" strokeWidth={2} />
        <Line x1={-8} y1={-25} x2={8} y2={-25} stroke="#1e40af" strokeWidth={2} />
        <Circle cx={0} cy={0} r={8} fill={isSimulationRunning ? "#3b82f6" : "#f1f5f9"} stroke="#1e40af" strokeWidth={2} />
        <SvgText x={0} y={25} fontSize={10} fill="#374151" textAnchor="middle">CYL</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'cap', x: -25, y: 0, type: 'inlet' },
      { id: 'rod', x: 25, y: 0, type: 'inlet' },
    ],
  },

  motor: {
    name: 'Hydraulic Motor',
    description: 'Fixed displacement hydraulic motor',
    category: 'actuators',
    renderIcon: () => createIcon(
      <>
        <Circle cx={16} cy={16} r={12} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Polygon points="16,12 20,16 16,20 12,16" fill="#2563eb" />
        <SvgText x={16} y={28} fontSize={8} fill="#2563eb" textAnchor="middle">M</SvgText>
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Circle cx={0} cy={0} r={25} fill="none" stroke="#1e40af" strokeWidth={2} />
        <Polygon points="0,-8 8,0 0,8 -8,0" fill={isSimulationRunning ? "#3b82f6" : "#64748b"} />
        <SvgText x={0} y={35} fontSize={10} fill="#374151" textAnchor="middle">M</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'inlet', x: -25, y: 0, type: 'inlet' },
      { id: 'outlet', x: 25, y: 0, type: 'outlet' },
    ],
  },

  filter: {
    name: 'Filter',
    description: 'Hydraulic filter',
    category: 'accessories',
    renderIcon: () => createIcon(
      <>
        <Line x1={8} y1={16} x2={24} y2={16} stroke="#2563eb" strokeWidth={2} />
        <Polygon points="12,12 20,12 16,20" fill="none" stroke="#2563eb" strokeWidth={2} />
        <Line x1={14} y1={16} x2={18} y2={16} stroke="#2563eb" strokeWidth={1} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Line x1={-25} y1={0} x2={25} y2={0} stroke="#1e40af" strokeWidth={2} />
        <Polygon points="-10,-10 10,-10 0,10" fill="none" stroke="#1e40af" strokeWidth={2} />
        {[...Array(5)].map((_, i) => (
          <Line key={i} x1={-8 + i * 4} y1={-5} x2={-8 + i * 4} y2={5} stroke="#1e40af" strokeWidth={1} />
        ))}
        <SvgText x={0} y={25} fontSize={10} fill="#374151" textAnchor="middle">F</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'inlet', x: -25, y: 0, type: 'inlet' },
      { id: 'outlet', x: 25, y: 0, type: 'outlet' },
    ],
  },

  reservoir: {
    name: 'Reservoir',
    description: 'Hydraulic fluid reservoir',
    category: 'accessories',
    renderIcon: () => createIcon(
      <>
        <Rect x={8} y={12} width={16} height={12} fill="none" stroke="#2563eb" strokeWidth={2} />
        <Line x1={8} y1={20} x2={24} y2={20} stroke="#2563eb" strokeWidth={1} />
        <Line x1={16} y1={12} x2={16} y2={8} stroke="#2563eb" strokeWidth={2} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Rect x={-20} y={-15} width={40} height={30} fill={isSimulationRunning ? "#dbeafe" : "#f8fafc"} stroke="#1e40af" strokeWidth={2} />
        <Line x1={-15} y1={5} x2={15} y2={5} stroke="#3b82f6" strokeWidth={1} />
        <Line x1={0} y1={-15} x2={0} y2={-25} stroke="#1e40af" strokeWidth={2} />
        <SvgText x={0} y={25} fontSize={10} fill="#374151" textAnchor="middle">T</SvgText>
      </>
    ),
    connectionPoints: [
      { id: 'return', x: 0, y: -25, type: 'inlet' },
      { id: 'suction', x: 0, y: 15, type: 'outlet' },
    ],
  },

  pipe: {
    name: 'Main Pipe',
    description: 'Main hydraulic line',
    category: 'connections',
    renderIcon: () => createIcon(
      <>
        <Line x1={8} y1={16} x2={24} y2={16} stroke="#2563eb" strokeWidth={3} />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Line x1={-25} y1={0} x2={25} y2={0} stroke="#1e40af" strokeWidth={3} />
      </>
    ),
    connectionPoints: [
      { id: 'start', x: -25, y: 0, type: 'inlet' },
      { id: 'end', x: 25, y: 0, type: 'outlet' },
    ],
  },

  'pilot-pipe': {
    name: 'Pilot Line',
    description: 'Pilot control line with dashed border',
    category: 'connections',
    renderIcon: () => createIcon(
      <>
        <Line x1={8} y1={16} x2={24} y2={16} stroke="#2563eb" strokeWidth={2} strokeDasharray="3,2" />
      </>
    ),
    renderSymbol: (component: ComponentData, isSimulationRunning: boolean) => createSymbol(
      <>
        <Line x1={-25} y1={0} x2={25} y2={0} stroke="#1e40af" strokeWidth={2} strokeDasharray="5,3" />
      </>
    ),
    connectionPoints: [
      { id: 'start', x: -25, y: 0, type: 'pilot' },
      { id: 'end', x: 25, y: 0, type: 'pilot' },
    ],
  },
};