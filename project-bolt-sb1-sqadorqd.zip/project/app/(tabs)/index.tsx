import React, { useState, useRef } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import CircuitCanvas from '@/components/CircuitCanvas';
import ComponentToolbar from '@/components/ComponentToolbar';
import ControlPanel from '@/components/ControlPanel';
import { ComponentProvider } from '@/contexts/ComponentContext';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

export default function CircuitSimulator() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [isSimulationRunning, setIsSimulationRunning] = useState(false);
  const canvasRef = useRef<any>(null);

  const handleToolSelect = (toolId: string) => {
    setSelectedTool(toolId === selectedTool ? null : toolId);
  };

  const handleSimulationToggle = () => {
    setIsSimulationRunning(!isSimulationRunning);
    if (canvasRef.current) {
      canvasRef.current.toggleSimulation(!isSimulationRunning);
    }
  };

  return (
    <GestureHandlerRootView style={styles.container}>
      <ComponentProvider>
        <SafeAreaView style={styles.container}>
          <View style={styles.header}>
            <ComponentToolbar
              selectedTool={selectedTool}
              onToolSelect={handleToolSelect}
            />
          </View>
          
          <View style={styles.canvasContainer}>
            <CircuitCanvas
              ref={canvasRef}
              selectedTool={selectedTool}
              isSimulationRunning={isSimulationRunning}
              onToolUsed={() => setSelectedTool(null)}
            />
          </View>
          
          <View style={styles.controls}>
            <ControlPanel
              isSimulationRunning={isSimulationRunning}
              onSimulationToggle={handleSimulationToggle}
            />
          </View>
        </SafeAreaView>
      </ComponentProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f1f5f9',
  },
  header: {
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  canvasContainer: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  controls: {
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
});