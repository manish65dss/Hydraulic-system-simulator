import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function SettingsScreen() {
  const [showGrid, setShowGrid] = useState(true);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [showFlow, setShowFlow] = useState(true);
  const [showPressure, setShowPressure] = useState(false);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Settings</Text>
        <Text style={styles.subtitle}>
          Configure simulator preferences
        </Text>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Canvas Settings</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Show Grid</Text>
            <Switch
              value={showGrid}
              onValueChange={setShowGrid}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor={showGrid ? '#ffffff' : '#f4f4f5'}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Snap to Grid</Text>
            <Switch
              value={snapToGrid}
              onValueChange={setSnapToGrid}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor={snapToGrid ? '#ffffff' : '#f4f4f5'}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Simulation Settings</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Show Flow Animation</Text>
            <Switch
              value={showFlow}
              onValueChange={setShowFlow}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor={showFlow ? '#ffffff' : '#f4f4f5'}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Show Pressure Values</Text>
            <Switch
              value={showPressure}
              onValueChange={setShowPressure}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor={showPressure ? '#ffffff' : '#f4f4f5'}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Physics Engine</Text>
          <Text style={styles.settingDescription}>
            Real-time fluid dynamics simulation with pressure calculations,
            flow rates, and system efficiency analysis.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 12,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  settingLabel: {
    fontSize: 16,
    color: '#374151',
    fontWeight: '500',
  },
  settingDescription: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
  },
});