import React from 'react';
import { TouchableOpacity } from 'react-native';
import Svg, { G } from 'react-native-svg';
import { componentTypes } from '@/utils/componentTypes';
import { ComponentData } from '@/types/component';

interface HydraulicComponentProps {
  component: ComponentData;
  isSimulationRunning: boolean;
}

export default function HydraulicComponent({ component, isSimulationRunning }: HydraulicComponentProps) {
  const componentType = componentTypes[component.type];
  
  if (!componentType) {
    return null;
  }

  return (
    <G
      transform={`translate(${component.x}, ${component.y}) rotate(${component.rotation})`}
    >
      {componentType.renderSymbol(component, isSimulationRunning)}
    </G>
  );
}