import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { componentTypes } from '@/utils/componentTypes';

interface ComponentToolbarProps {
  selectedTool: string | null;
  onToolSelect: (toolId: string) => void;
}

export default function ComponentToolbar({ selectedTool, onToolSelect }: ComponentToolbarProps) {
  const categories = [
    { id: 'pumps', name: 'Pumps', components: ['pump', 'variable-pump'] },
    { id: 'valves', name: 'Valves', components: ['directional-valve', 'relief-valve', 'check-valve', 'flow-control-valve'] },
    { id: 'actuators', name: 'Actuators', components: ['cylinder', 'motor'] },
    { id: 'filters', name: 'Filters', components: ['filter', 'reservoir'] },
    { id: 'pipes', name: 'Pipes', components: ['pipe', 'pilot-pipe'] },
  ];

  return (
    <View style={styles.container}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {categories.map((category) => (
          <View key={category.id} style={styles.category}>
            <Text style={styles.categoryTitle}>{category.name}</Text>
            <View style={styles.componentRow}>
              {category.components.map((componentId) => {
                const component = componentTypes[componentId];
                const isSelected = selectedTool === componentId;
                
                return (
                  <TouchableOpacity
                    key={componentId}
                    style={[
                      styles.componentButton,
                      isSelected && styles.componentButtonSelected,
                    ]}
                    onPress={() => onToolSelect(componentId)}
                  >
                    <View style={styles.componentIcon}>
                      {component.renderIcon()}
                    </View>
                    <Text style={[
                      styles.componentName,
                      isSelected && styles.componentNameSelected,
                    ]}>
                      {component.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 12,
    backgroundColor: '#ffffff',
  },
  category: {
    marginRight: 24,
    paddingHorizontal: 12,
  },
  categoryTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
    textAlign: 'center',
  },
  componentRow: {
    flexDirection: 'row',
  },
  componentButton: {
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 8,
    marginHorizontal: 4,
    borderRadius: 8,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    minWidth: 60,
  },
  componentButtonSelected: {
    backgroundColor: '#dbeafe',
    borderColor: '#3b82f6',
  },
  componentIcon: {
    marginBottom: 4,
  },
  componentName: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center',
  },
  componentNameSelected: {
    color: '#1e40af',
    fontWeight: '600',
  },
});