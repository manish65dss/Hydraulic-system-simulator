import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { componentTypes } from '@/utils/componentTypes';

export default function ComponentLibrary() {
  const categories = [
    {
      title: 'Pumps & Motors',
      components: ['pump', 'variable-pump', 'motor'],
    },
    {
      title: 'Directional Control Valves',
      components: ['directional-valve'],
    },
    {
      title: 'Pressure Control Valves',
      components: ['relief-valve', 'check-valve'],
    },
    {
      title: 'Flow Control Valves',
      components: ['flow-control-valve'],
    },
    {
      title: 'Actuators',
      components: ['cylinder'],
    },
    {
      title: 'Accessories',
      components: ['filter', 'reservoir', 'pipe', 'pilot-pipe'],
    },
  ];

  return (
    <View style={styles.container}>
      {categories.map((category) => (
        <View key={category.title} style={styles.category}>
          <Text style={styles.categoryTitle}>{category.title}</Text>
          <View style={styles.componentsGrid}>
            {category.components.map((componentId) => {
              const component = componentTypes[componentId];
              return (
                <View key={componentId} style={styles.componentItem}>
                  <View style={styles.componentIcon}>
                    {component.renderIcon()}
                  </View>
                  <Text style={styles.componentName}>{component.name}</Text>
                  <Text style={styles.componentDescription}>
                    {component.description}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  category: {
    marginBottom: 32,
  },
  categoryTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
  },
  componentsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  componentItem: {
    width: '47%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  componentIcon: {
    marginBottom: 12,
  },
  componentName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    textAlign: 'center',
    marginBottom: 4,
  },
  componentDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 18,
  },
});