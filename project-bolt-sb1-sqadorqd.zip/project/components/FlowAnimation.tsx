import React, { useEffect } from 'react';
import { Circle, Line } from 'react-native-svg';
import Animated, {
  useSharedValue,
  useAnimatedProps,
  withRepeat,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { ComponentData, Connection } from '@/types/component';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);
const AnimatedLine = Animated.createAnimatedComponent(Line);

interface FlowAnimationProps {
  connections: Connection[];
  components: ComponentData[];
}

export default function FlowAnimation({ connections, components }: FlowAnimationProps) {
  const animationProgress = useSharedValue(0);

  useEffect(() => {
    animationProgress.value = withRepeat(
      withTiming(1, { duration: 2000 }),
      -1,
      false
    );
  }, []);

  const renderFlowParticles = (connection: Connection) => {
    const particles = [];
    const particleCount = 5;
    
    for (let i = 0; i < particleCount; i++) {
      const animatedProps = useAnimatedProps(() => {
        const progress = (animationProgress.value + i / particleCount) % 1;
        const x = interpolate(
          progress,
          [0, 1],
          [connection.fromX, connection.toX]
        );
        const y = interpolate(
          progress,
          [0, 1],
          [connection.fromY, connection.toY]
        );
        
        return {
          cx: x,
          cy: y,
          opacity: interpolate(progress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]),
        };
      });

      particles.push(
        <AnimatedCircle
          key={`particle-${connection.id}-${i}`}
          r={3}
          fill="#3b82f6"
          animatedProps={animatedProps}
        />
      );
    }
    
    return particles;
  };

  return (
    <>
      {connections.map((connection) => (
        <React.Fragment key={connection.id}>
          <Line
            x1={connection.fromX}
            y1={connection.fromY}
            x2={connection.toX}
            y2={connection.toY}
            stroke="#2563eb"
            strokeWidth={3}
            strokeOpacity={0.3}
          />
          {renderFlowParticles(connection)}
        </React.Fragment>
      ))}
    </>
  );
}