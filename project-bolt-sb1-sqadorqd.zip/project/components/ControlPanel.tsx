import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Play, Pause, RotateCcw, Zap } from 'lucide-react-native';

interface ControlPanelProps {
  isSimulationRunning: boolean;
  onSimulationToggle: () => void;
}

export default function ControlPanel({ isSimulationRunning, onSimulationToggle }: ControlPanelProps) {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[
          styles.primaryButton,
          isSimulationRunning ? styles.stopButton : styles.startButton,
        ]}
        onPress={onSimulationToggle}
      >
        {isSimulationRunning ? (
          <Pause size={20} color="#ffffff" />
        ) : (
          <Play size={20} color="#ffffff" />
        )}
        <Text style={styles.primaryButtonText}>
          {isSimulationRunning ? 'Stop' : 'Start'} Simulation
        </Text>
      </TouchableOpacity>

      <View style={styles.secondaryControls}>
        <TouchableOpacity style={styles.secondaryButton}>
          <RotateCcw size={18} color="#374151" />
          <Text style={styles.secondaryButtonText}>Reset</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.secondaryButton}>
          <Zap size={18} color="#374151" />
          <Text style={styles.secondaryButtonText}>Analyze</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
  },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  startButton: {
    backgroundColor: '#10b981',
  },
  stopButton: {
    backgroundColor: '#ef4444',
  },
  primaryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  secondaryControls: {
    flexDirection: 'row',
    gap: 8,
  },
  secondaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 6,
    backgroundColor: '#f1f5f9',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  secondaryButtonText: {
    color: '#374151',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 6,
  },
});