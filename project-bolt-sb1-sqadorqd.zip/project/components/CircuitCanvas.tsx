import React, { useState, useRef, forwardRef, useImperativeHandle } from 'react';
import { View, StyleSheet, Dimensions, PanResponder } from 'react-native';
import Svg, { Defs, Pattern, Rect, Line, G } from 'react-native-svg';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  runOnJS,
} from 'react-native-reanimated';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import HydraulicComponent from './HydraulicComponent';
import FlowAnimation from './FlowAnimation';
import { useComponentContext } from '@/contexts/ComponentContext';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

interface CircuitCanvasProps {
  selectedTool: string | null;
  isSimulationRunning: boolean;
  onToolUsed: () => void;
}

const CircuitCanvas = forwardRef<any, CircuitCanvasProps>(
  ({ selectedTool, isSimulationRunning, onToolUsed }, ref) => {
    const { components, addComponent, connections } = useComponentContext();
    const [canvasSize] = useState({ width: screenWidth * 2, height: screenHeight * 2 });
    const [zoom, setZoom] = useState(1);
    const translateX = useSharedValue(0);
    const translateY = useSharedValue(0);
    const scale = useSharedValue(1);

    useImperativeHandle(ref, () => ({
      toggleSimulation: (running: boolean) => {
        // Handle simulation state changes
      },
    }));

    const handleCanvasTap = (x: number, y: number) => {
      if (selectedTool) {
        const adjustedX = (x - translateX.value) / scale.value;
        const adjustedY = (y - translateY.value) / scale.value;
        
        addComponent({
          id: `${selectedTool}-${Date.now()}`,
          type: selectedTool,
          x: adjustedX,
          y: adjustedY,
          rotation: 0,
          properties: {},
        });
        
        onToolUsed();
      }
    };

    const panGesture = Gesture.Pan()
      .onUpdate((event) => {
        translateX.value = event.translationX;
        translateY.value = event.translationY;
      })
      .onEnd(() => {
        translateX.value = withSpring(translateX.value);
        translateY.value = withSpring(translateY.value);
      });

    const pinchGesture = Gesture.Pinch()
      .onUpdate((event) => {
        scale.value = Math.max(0.5, Math.min(3, event.scale));
      })
      .onEnd(() => {
        scale.value = withSpring(scale.value);
        runOnJS(setZoom)(scale.value);
      });

    const tapGesture = Gesture.Tap()
      .onEnd((event) => {
        runOnJS(handleCanvasTap)(event.x, event.y);
      });

    const combinedGesture = Gesture.Simultaneous(
      panGesture,
      pinchGesture,
      tapGesture
    );

    const animatedStyle = useAnimatedStyle(() => {
      return {
        transform: [
          { translateX: translateX.value },
          { translateY: translateY.value },
          { scale: scale.value },
        ],
      };
    });

    const renderGrid = () => {
      const gridSize = 20;
      const lines = [];
      
      for (let i = 0; i <= canvasSize.width / gridSize; i++) {
        lines.push(
          <Line
            key={`v-${i}`}
            x1={i * gridSize}
            y1={0}
            x2={i * gridSize}
            y2={canvasSize.height}
            stroke="#e2e8f0"
            strokeWidth={0.5}
          />
        );
      }
      
      for (let i = 0; i <= canvasSize.height / gridSize; i++) {
        lines.push(
          <Line
            key={`h-${i}`}
            x1={0}
            y1={i * gridSize}
            x2={canvasSize.width}
            y2={i * gridSize}
            stroke="#e2e8f0"
            strokeWidth={0.5}
          />
        );
      }
      
      return lines;
    };

    return (
      <View style={styles.container}>
        <GestureDetector gesture={combinedGesture}>
          <Animated.View style={[styles.canvas, animatedStyle]}>
            <Svg
              width={canvasSize.width}
              height={canvasSize.height}
              style={styles.svg}
            >
              <Defs>
                <Pattern
                  id="grid"
                  patternUnits="userSpaceOnUse"
                  width={20}
                  height={20}
                >
                  <Rect width={20} height={20} fill="none" />
                  <Line x1={0} y1={0} x2={20} y2={0} stroke="#e2e8f0" strokeWidth={0.5} />
                  <Line x1={0} y1={0} x2={0} y2={20} stroke="#e2e8f0" strokeWidth={0.5} />
                </Pattern>
              </Defs>
              
              <Rect
                width={canvasSize.width}
                height={canvasSize.height}
                fill="url(#grid)"
              />
              
              <G>
                {components.map((component) => (
                  <HydraulicComponent
                    key={component.id}
                    component={component}
                    isSimulationRunning={isSimulationRunning}
                  />
                ))}
                
                {isSimulationRunning && (
                  <FlowAnimation
                    connections={connections}
                    components={components}
                  />
                )}
              </G>
            </Svg>
          </Animated.View>
        </GestureDetector>
      </View>
    );
  }
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    overflow: 'hidden',
  },
  canvas: {
    flex: 1,
  },
  svg: {
    backgroundColor: '#ffffff',
  },
});

export default CircuitCanvas;